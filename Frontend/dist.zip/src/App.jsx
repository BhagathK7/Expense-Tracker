import Counter from "./components/Counter";
import ExpenseContainer from "./components/ExpenseContainer";

const App=() => {
  return (
    <div className="App">
      <ExpenseContainer/>
    </div>
  );
}

export default App;