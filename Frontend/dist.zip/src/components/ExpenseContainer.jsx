import History from './History';
import { useState } from 'react';
import ExpenseForm from './ExpenseForm';
import BalanceContainer from './BalanceContainer';
import { v4 as uid } from 'uuid';

const ExpenseContainer = () => {
  const EXPENSES = [
    { id: uid(), title: "Expense 1", expense: 100 },
    { id: uid(), title: "Expense 2", expense: -200 }
  ];

  const [expenses, setExpenses] = useState(EXPENSES);
  const [editData, setEditData] = useState(null);

  const addExpense = (title, expense) => {
    if (editData) {
      setExpenses(prev =>
        prev.map((item) =>
          item.id === editData.id ? { ...item, title, expense } : item
        )
      );
      setEditData(null);
    } else {
      setExpenses([...expenses, { id: uid(), title, expense }]);
    }
  };

  const deleteExpense = (id) => {
    setExpenses(expenses.filter((item) => item.id !== id));
  };

  const editExpense = (item) => {
    setEditData(item);
  };

  return (
    <div className="expense-container">
      <center><h2>Expense Tracker</h2></center>
      <BalanceContainer expenseArr={expenses} />
      <ExpenseForm expenses={addExpense} editData={editData} setEditData={setEditData} />
      <History expenses={expenses} deleteExpense={deleteExpense} editExpense={editExpense} editData={editData}/>

      
    </div>
  );
};

export default ExpenseContainer;
