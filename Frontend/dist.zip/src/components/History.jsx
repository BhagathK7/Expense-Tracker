import ExpenseItem from './ExpenseItem';

const History = (props) => {
  const { expenses, deleteExpense, editExpense, editData } = props;

  return (
    <div className="history">
      <h3>History</h3>
      {expenses.map((exp) => (
        <ExpenseItem
          key={exp.id}
          id={exp.id}
          title={exp.title}
          expense={exp.expense}
          deleteExpense={deleteExpense}
          editExpense={() => editExpense(exp)}
          isEditing={editData && editData.id === exp.id}
        />
      ))}
    </div>
  );
};

export default History;
